﻿class Musique{
  constructor(nom, artiste, style, id, datedesortie, label, duree, certification, positionusa, topglobal = null){
    this.nom = nom;
    this.artiste = artiste;
    this.style = style;
    this.id = id;
    this.datedesortie = datedesortie;
    this.label = label;
    this.duree = duree;
    this.certification = certification;
    this.positionusa = positionusa;
    this.topglobal = topglobal;

  }

}
